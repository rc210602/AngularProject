import { Component } from '@angular/core';

@Component({
  selector: 'app-chowdrah-foot',
  templateUrl: './chowdrah-foot.component.html',
  styleUrls: ['./chowdrah-foot.component.css']
})
export class ChowdrahFootComponent {
  cdate=new Date();
}
