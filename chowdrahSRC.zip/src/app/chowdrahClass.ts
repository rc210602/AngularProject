

export class chowdrahBio {
    fname!:string
    lname!: string 
    snumber!: number
    username!: string
    email!: string
    personal_image_name!: string
    rejection_image_name!: string

}